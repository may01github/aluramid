function tocaSom(){
    document.querySelector('#som_tecla_pom').play('');
}

const listadeTeclas = document.querySelectorAll('.tecla')








